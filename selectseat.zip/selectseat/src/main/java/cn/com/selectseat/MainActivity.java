package cn.com.selectseat;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    SeatTable seatTable;
    HorizontalListView horizontalListView;
    List<String> datas = new ArrayList<>();
    HlistviewAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        seatTable = (SeatTable) findViewById(R.id.seat);
        horizontalListView = (HorizontalListView) findViewById(R.id.hlistview);
        adapter = new HlistviewAdapter();
        horizontalListView.setAdapter(adapter);
        seatTable.setScreenName("8号厅荧幕");//设置屏幕名称
        seatTable.setMaxSelected(4);//设置最多选中
        seatTable.setSeatChecker(new SeatTable.SeatChecker() {
            //判断几排几列的座位是,可以当作是走廊，根据传入的坐标来判断座位的状态
            @Override
            public boolean isValidSeat(int row, int column) {
                if(row==3) {
                    return false;
                }
                return true;
            }
            //已售座位，
            @Override
            public boolean isSold(int row, int column) {
                if(row==5&&column==5){
                    return true;
                }
                if(row==4&&column==4){
                    return true;
                }
                return false;
            }
            //选中座位的监听
            @Override
            public void checked(int row, int column) {
                Toast.makeText(MainActivity.this,(row+1)+"排"+(column+1)+"座",Toast.LENGTH_SHORT).show();

            }
            //取消已选中座位的监听
            @Override
            public void unCheck(int row, int column) {
                Toast.makeText(MainActivity.this,"取消了"+(row+1)+"排"+(column+1)+"座",Toast.LENGTH_SHORT).show();

            }
            //情侣座的判断
            @Override
            public boolean isFriends(int row, int column) {
                if(row==6) {
                    return true;
                }
                return false;
            }
            //座位是否可以点击，如果作为已经被选择，则不可以点击
            @Override
            public boolean isEmpty(int row, int column) {

                return true;
            }
            //点击座位之后，在座位上显示的字体
            @Override
            public String[] checkedSeatTxt(int row, int column) {
                return null;
            }

        });
        seatTable.setData(8,13);
        horizontalListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });
    }
    class HlistviewAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return datas.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView = View.inflate(MainActivity.this,R.layout.hlistview_item,null);
            TextView tvSeat = (TextView) convertView.findViewById(R.id.tv_seat);
            tvSeat.setText(datas.get(position));
            return convertView;
        }
    }

    class SeatListener implements SeatTable.SeatChecker{

        @Override
        public boolean isValidSeat(int row, int column) {
            return false;
        }

        @Override
        public boolean isSold(int row, int column) {
            return false;
        }

        @Override
        public void checked(int row, int column) {

        }

        @Override
        public void unCheck(int row, int column) {

        }

        @Override
        public boolean isFriends(int row, int column) {
            return false;
        }

        @Override
        public boolean isEmpty(int row, int column) {
            return false;
        }

        @Override
        public String[] checkedSeatTxt(int row, int column) {
            return new String[0];
        }
    }
}
